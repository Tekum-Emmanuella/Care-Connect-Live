import {
  type Patient,
  type InsertPatient,
  type Doctor,
  type InsertDoctor,
  type Hospital,
  type InsertHospital,
  type Appointment,
  type InsertAppointment,
  type Transfer,
  type InsertTransfer,
  patients,
  doctors,
  hospitals,
  appointments,
  transfers,
} from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq, desc, ilike, or } from "drizzle-orm";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is not set");
}

const client = postgres(process.env.DATABASE_URL);
export const db = drizzle(client);

export interface IStorage {
  // Patients
  getPatients(): Promise<Patient[]>;
  getPatient(id: string): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  
  // Doctors
  getDoctors(): Promise<Doctor[]>;
  getDoctor(id: string): Promise<Doctor | undefined>;
  searchDoctors(query: string): Promise<Doctor[]>;
  createDoctor(doctor: InsertDoctor): Promise<Doctor>;
  
  // Hospitals
  getHospitals(): Promise<Hospital[]>;
  getHospital(id: string): Promise<Hospital | undefined>;
  searchHospitals(query: string): Promise<Hospital[]>;
  createHospital(hospital: InsertHospital): Promise<Hospital>;
  
  // Appointments
  getAppointments(): Promise<Appointment[]>;
  getAppointment(id: string): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  
  // Transfers
  getTransfers(): Promise<Transfer[]>;
  getTransfer(id: string): Promise<Transfer | undefined>;
  createTransfer(transfer: InsertTransfer): Promise<Transfer>;
  updateTransferStatus(id: string, status: 'pending' | 'accepted' | 'completed'): Promise<Transfer | undefined>;
}

export class DatabaseStorage implements IStorage {
  // Patients
  async getPatients(): Promise<Patient[]> {
    return await db.select().from(patients).orderBy(desc(patients.createdAt));
  }

  async getPatient(id: string): Promise<Patient | undefined> {
    const result = await db.select().from(patients).where(eq(patients.id, id));
    return result[0];
  }

  async createPatient(patient: InsertPatient): Promise<Patient> {
    const result = await db.insert(patients).values(patient).returning();
    return result[0];
  }

  // Doctors
  async getDoctors(): Promise<Doctor[]> {
    return await db.select().from(doctors);
  }

  async getDoctor(id: string): Promise<Doctor | undefined> {
    const result = await db.select().from(doctors).where(eq(doctors.id, id));
    return result[0];
  }

  async searchDoctors(query: string): Promise<Doctor[]> {
    const searchTerm = `%${query}%`;
    return await db
      .select()
      .from(doctors)
      .where(
        or(
          ilike(doctors.name, searchTerm),
          ilike(doctors.specialty, searchTerm),
          ilike(doctors.location, searchTerm)
        )
      );
  }

  async createDoctor(doctor: InsertDoctor): Promise<Doctor> {
    const result = await db.insert(doctors).values(doctor).returning();
    return result[0];
  }

  // Hospitals
  async getHospitals(): Promise<Hospital[]> {
    return await db.select().from(hospitals);
  }

  async getHospital(id: string): Promise<Hospital | undefined> {
    const result = await db.select().from(hospitals).where(eq(hospitals.id, id));
    return result[0];
  }

  async searchHospitals(query: string): Promise<Hospital[]> {
    const searchTerm = `%${query}%`;
    return await db
      .select()
      .from(hospitals)
      .where(
        or(
          ilike(hospitals.name, searchTerm),
          ilike(hospitals.location, searchTerm),
          ilike(hospitals.type, searchTerm)
        )
      );
  }

  async createHospital(hospital: InsertHospital): Promise<Hospital> {
    const result = await db.insert(hospitals).values(hospital).returning();
    return result[0];
  }

  // Appointments
  async getAppointments(): Promise<Appointment[]> {
    return await db.select().from(appointments).orderBy(desc(appointments.createdAt));
  }

  async getAppointment(id: string): Promise<Appointment | undefined> {
    const result = await db.select().from(appointments).where(eq(appointments.id, id));
    return result[0];
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const result = await db.insert(appointments).values(appointment).returning();
    return result[0];
  }

  // Transfers
  async getTransfers(): Promise<Transfer[]> {
    return await db.select().from(transfers).orderBy(desc(transfers.createdAt));
  }

  async getTransfer(id: string): Promise<Transfer | undefined> {
    const result = await db.select().from(transfers).where(eq(transfers.id, id));
    return result[0];
  }

  async createTransfer(transfer: InsertTransfer): Promise<Transfer> {
    const result = await db.insert(transfers).values(transfer).returning();
    return result[0];
  }

  async updateTransferStatus(
    id: string,
    status: 'pending' | 'accepted' | 'completed'
  ): Promise<Transfer | undefined> {
    const result = await db
      .update(transfers)
      .set({ status })
      .where(eq(transfers.id, id))
      .returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();

import { storage } from "./storage";

async function seed() {
  console.log("Seeding database...");

  // Seed Hospitals
  const hospitals = [
    {
      name: 'Yaoundé Central Hospital',
      location: 'Yaoundé',
      type: 'General' as const,
      image: 'https://images.unsplash.com/photo-1587351021759-3e566b9af9ef?auto=format&fit=crop&q=80&w=800',
      facilities: ['24/7 Trauma Center', 'MRI/CT Scan', 'Helipad', 'Advanced ICU'],
      specialties: ['Cardiology', 'Neurology', 'Oncology', 'Trauma'],
      rating: 48,
      ambulanceAvailable: true,
      icuBeds: 12
    },
    {
      name: 'Douala General Hospital',
      location: 'Douala',
      type: 'General' as const,
      image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=800',
      facilities: ['Neonatal ICU', 'Dialysis Center', 'Telemedicine Hub'],
      specialties: ['Pediatrics', 'Nephrology', 'Internal Medicine'],
      rating: 47,
      ambulanceAvailable: true,
      icuBeds: 8
    },
    {
      name: 'Bafut Medical Center',
      location: 'Bafut',
      type: 'Clinic' as const,
      image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=800',
      facilities: ['Basic Emergency', 'Maternity Ward', 'Pharmacy'],
      specialties: ['General Practice', 'Maternity'],
      rating: 45,
      ambulanceAvailable: false,
      icuBeds: 0
    },
    {
      name: 'Buea Heart Institute',
      location: 'Buea',
      type: 'Specialized' as const,
      image: 'https://images.unsplash.com/photo-1632833239869-a37e3a5806d2?auto=format&fit=crop&q=80&w=800',
      facilities: ['Cardiac Cath Lab', 'Cardiac ICU', 'Rehabilitation Gym'],
      specialties: ['Cardiology', 'Cardiothoracic Surgery'],
      rating: 49,
      ambulanceAvailable: true,
      icuBeds: 5
    }
  ];

  for (const hospital of hospitals) {
    await storage.createHospital(hospital);
  }

  // Seed Doctors
  const doctors = [
    {
      name: 'Dr. Sarah Etoga',
      specialty: 'Cardiologist',
      hospital: 'Yaoundé Central Hospital',
      location: 'Yaoundé',
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200',
      availableSlots: ['09:00', '10:30', '14:00', '16:00'],
      rating: 48
    },
    {
      name: 'Dr. Marcus Fomunyuy',
      specialty: 'Pediatrician',
      hospital: 'Douala General Hospital',
      location: 'Douala',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=200',
      availableSlots: ['08:00', '11:00', '13:30', '15:00'],
      rating: 49
    },
    {
      name: 'Dr. Amina Bello',
      specialty: 'Dermatologist',
      hospital: 'Bamenda Regional Hospital',
      location: 'Bamenda',
      image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=200',
      availableSlots: ['09:30', '10:00', '12:00'],
      rating: 47
    },
    {
      name: 'Dr. Jean-Claude Ngue',
      specialty: 'General Practitioner',
      hospital: 'Buea Regional Hospital',
      location: 'Buea',
      image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=200',
      availableSlots: ['08:30', '09:00', '09:30', '10:00', '10:30'],
      rating: 46
    }
  ];

  for (const doctor of doctors) {
    await storage.createDoctor(doctor);
  }

  // Seed Patients
  const patients = [
    {
      name: 'Amara N.',
      age: 34,
      village: 'Bafut',
      symptoms: 'Persistent cough, fever',
      temperature: 385,
      bloodPressure: '120/80',
      heartRate: 88,
      severity: 'medium',
      medicalHistory: ['Asthma', 'Malaria (2023)'],
      allergies: ['Penicillin'],
      currentMedications: ['Ibuprofen'],
      bloodType: 'O+',
      synced: true
    },
    {
      name: 'Jean-Pierre K.',
      age: 62,
      village: 'Bali',
      symptoms: 'Chest pain, shortness of breath',
      temperature: 372,
      bloodPressure: '150/95',
      heartRate: 92,
      severity: 'critical',
      medicalHistory: ['Hypertension', 'Type 2 Diabetes'],
      allergies: ['None'],
      currentMedications: ['Metformin', 'Lisinopril'],
      bloodType: 'A-',
      synced: true
    }
  ];

  for (const patient of patients) {
    await storage.createPatient(patient);
  }

  console.log("Database seeded successfully!");
}

seed().catch(console.error);

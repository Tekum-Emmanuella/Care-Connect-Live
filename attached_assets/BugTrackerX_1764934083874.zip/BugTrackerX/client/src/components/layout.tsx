import { Link, useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { 
  Activity, 
  Wifi, 
  WifiOff, 
  Database, 
  User, 
  LogOut,
  LayoutDashboard,
  ClipboardPlus,
  Menu,
  HeartPulse,
  Search
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import logoImage from "@assets/generated_images/minimalist_medical_connectivity_logo.png";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { isOffline, toggleOffline, syncQueue, currentUser, setRole } = useStore();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    setRole(null);
    setLocation("/");
  };

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 flex items-center gap-3 border-b border-white/10">
        <div className="bg-white p-1.5 rounded-xl shadow-lg shadow-primary/20">
           <img src={logoImage} alt="HealthHub Logo" className="w-8 h-8" />
        </div>
        <div>
          <h1 className="font-heading font-bold text-lg text-white leading-none tracking-tight">HealthHub</h1>
          <p className="text-xs text-white/60 font-medium">Cameroon</p>
        </div>
      </div>

      <div className="flex-1 py-8 px-4 space-y-2">
        {currentUser === 'nurse' && (
          <Button 
            variant={location === "/nurse" ? "secondary" : "ghost"} 
            className={`w-full justify-start font-medium ${location === "/nurse" ? "bg-white text-sidebar shadow-md" : "text-white/70 hover:text-white hover:bg-white/10"}`}
            asChild
          >
            <Link href="/nurse">
              <ClipboardPlus className="mr-3 h-5 w-5" />
              Intake Form
            </Link>
          </Button>
        )}

        {currentUser === 'specialist' && (
          <Button 
            variant={location === "/specialist" ? "secondary" : "ghost"} 
            className={`w-full justify-start font-medium ${location === "/specialist" ? "bg-white text-sidebar shadow-md" : "text-white/70 hover:text-white hover:bg-white/10"}`}
            asChild
          >
            <Link href="/specialist">
              <LayoutDashboard className="mr-3 h-5 w-5" />
              Dashboard
            </Link>
          </Button>
        )}

        {currentUser === 'patient' && (
          <Button 
            variant={location === "/patient" ? "secondary" : "ghost"} 
            className={`w-full justify-start font-medium ${location === "/patient" ? "bg-white text-sidebar shadow-md" : "text-white/70 hover:text-white hover:bg-white/10"}`}
            asChild
          >
            <Link href="/patient">
              <HeartPulse className="mr-3 h-5 w-5" />
              My Health
            </Link>
          </Button>
        )}
      </div>

      <div className="p-4 border-t border-white/10 bg-black/20 backdrop-blur-md">
        {currentUser !== 'patient' && (
          <div className="mb-4 p-3 rounded-xl bg-black/20 border border-white/5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase tracking-widest font-bold text-white/50">System Status</span>
              <Button 
                size="icon" 
                variant="ghost" 
                className="h-6 w-6 text-white hover:bg-white/10 rounded-full"
                onClick={toggleOffline}
              >
                {isOffline ? <WifiOff className="h-3.5 w-3.5 text-red-400" /> : <Wifi className="h-3.5 w-3.5 text-green-400" />}
              </Button>
            </div>
            
            <div className="flex items-center justify-between text-xs text-white/80 font-mono">
              <span>{isOffline ? "Offline" : "Online"}</span>
              <AnimatePresence>
                {syncQueue.length > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center gap-1.5 text-orange-300 font-bold"
                  >
                    <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
                    {syncQueue.length} Syncing
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-white">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-primary to-purple-400 flex items-center justify-center shadow-inner border border-white/20">
              <User className="h-4 w-4 text-white" />
            </div>
            <div className="text-sm">
              <p className="font-bold capitalize leading-tight">{currentUser}</p>
              <p className="text-xs text-white/50">Logged In</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={handleLogout} className="text-white/50 hover:text-white hover:bg-white/10 rounded-full">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );

  if (!currentUser) return <div className="bg-background min-h-screen">{children}</div>;

  return (
    <div className="min-h-screen flex bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-72 bg-sidebar border-r border-sidebar-border flex-shrink-0 shadow-2xl z-20">
        <NavContent />
      </aside>

      {/* Mobile Header */}
      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        <header className="md:hidden h-16 border-b border-border/50 bg-sidebar/95 backdrop-blur flex items-center justify-between px-4 text-white sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <img src={logoImage} alt="Logo" className="w-8 h-8 rounded bg-white p-0.5" />
            <span className="font-heading font-bold">HealthHub</span>
          </div>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 bg-sidebar w-72 border-r-sidebar-border text-sidebar-foreground">
              <NavContent />
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

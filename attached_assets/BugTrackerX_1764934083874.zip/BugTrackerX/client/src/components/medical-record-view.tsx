import { Patient } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  Pill, 
  AlertTriangle, 
  Droplet,
  History
} from "lucide-react";

interface MedicalRecordViewProps {
  patient: Patient;
  compact?: boolean;
}

export function MedicalRecordView({ patient, compact = false }: MedicalRecordViewProps) {
  return (
    <div className="space-y-6">
      {/* Vitals Summary */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-blue-50/50 border-blue-100 shadow-none">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1 flex items-center justify-center gap-1">
              <Activity className="w-3 h-3" /> Heart Rate
            </div>
            <div className="text-2xl font-black text-blue-700">{patient.heartRate} <span className="text-sm font-normal text-muted-foreground">bpm</span></div>
          </CardContent>
        </Card>
        <Card className="bg-green-50/50 border-green-100 shadow-none">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1 flex items-center justify-center gap-1">
              <Activity className="w-3 h-3" /> BP
            </div>
            <div className="text-2xl font-black text-green-700">{patient.bloodPressure}</div>
          </CardContent>
        </Card>
        <Card className="bg-orange-50/50 border-orange-100 shadow-none">
          <CardContent className="p-4 text-center">
            <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1 flex items-center justify-center gap-1">
              <Activity className="w-3 h-3" /> Temp
            </div>
            <div className="text-2xl font-black text-orange-700">{patient.temperature}°C</div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Records */}
      {!compact && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <History className="w-4 h-4 text-primary" /> Medical History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {patient.medicalHistory && patient.medicalHistory.length > 0 ? (
                <ul className="space-y-2">
                  {patient.medicalHistory.map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary/40" />
                      {item}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground italic">No significant history recorded.</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Pill className="w-4 h-4 text-purple-500" /> Current Medications
              </CardTitle>
            </CardHeader>
            <CardContent>
              {patient.currentMedications && patient.currentMedications.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {patient.currentMedications.map((med, i) => (
                    <Badge key={i} variant="secondary" className="bg-purple-50 text-purple-700 border-purple-100">
                      {med}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">No active medications.</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-500" /> Allergies
              </CardTitle>
            </CardHeader>
            <CardContent>
              {patient.allergies && patient.allergies.length > 0 && patient.allergies[0] !== 'None' ? (
                <div className="flex flex-wrap gap-2">
                  {patient.allergies.map((alg, i) => (
                    <Badge key={i} variant="destructive" className="bg-red-50 text-red-700 border-red-100 hover:bg-red-100">
                      {alg}
                    </Badge>
                  ))}
                </div>
              ) : (
                <div className="flex items-center gap-2 text-sm text-green-600 font-medium">
                  <div className="w-2 h-2 rounded-full bg-green-500" /> No Known Allergies
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Droplet className="w-4 h-4 text-red-600" /> Blood Type
              </CardTitle>
            </CardHeader>
            <CardContent>
               <div className="text-3xl font-black text-red-600/20 font-mono tracking-tighter">
                 {patient.bloodType || "Unknown"}
               </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

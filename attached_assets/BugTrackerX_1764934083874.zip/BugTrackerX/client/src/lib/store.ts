import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface OfflineQueueItem {
  type: 'patient' | 'appointment' | 'transfer';
  data: any;
  timestamp: string;
}

interface AppState {
  isOffline: boolean;
  syncQueue: OfflineQueueItem[];
  currentUser: 'nurse' | 'specialist' | 'patient' | null;
  
  toggleOffline: () => void;
  setRole: (role: 'nurse' | 'specialist' | 'patient' | null) => void;
  addToSyncQueue: (item: OfflineQueueItem) => void;
  clearSyncQueue: () => void;
  getSyncQueueCount: () => number;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      isOffline: false,
      syncQueue: [],
      currentUser: null,

      toggleOffline: () => set((state) => ({
        isOffline: !state.isOffline
      })),

      setRole: (role) => set({ currentUser: role }),

      addToSyncQueue: (item) => set((state) => ({
        syncQueue: [...state.syncQueue, item]
      })),

      clearSyncQueue: () => set({ syncQueue: [] }),

      getSyncQueueCount: () => get().syncQueue.length,
    }),
    {
      name: 'healthhub-storage',
      partialize: (state) => ({
        syncQueue: state.syncQueue,
        currentUser: state.currentUser,
      }),
    }
  )
);

// API client functions for backend communication

export interface Patient {
  id: string;
  name: string;
  age: number;
  village: string;
  symptoms: string;
  temperature: number;
  bloodPressure: string;
  heartRate: number;
  severity: 'low' | 'medium' | 'critical';
  medicalHistory: string[];
  allergies: string[];
  currentMedications: string[];
  bloodType: string;
  synced: boolean;
  createdAt: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  hospital: string;
  location: string;
  image: string;
  availableSlots: string[];
  rating: number;
}

export interface Hospital {
  id: string;
  name: string;
  location: string;
  type: 'General' | 'Specialized' | 'Clinic';
  image: string;
  facilities: string[];
  specialties: string[];
  rating: number;
  ambulanceAvailable: boolean;
  icuBeds: number;
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  hospital: string;
  date: string;
  time: string;
  status: 'confirmed' | 'pending' | 'completed';
  videoLink?: string;
  createdAt: string;
}

export interface Transfer {
  id: string;
  patientId: string;
  patientName: string;
  fromHospitalId: string;
  toHospitalId: string;
  reason: string;
  priority: 'routine' | 'urgent' | 'emergency';
  status: 'pending' | 'accepted' | 'completed';
  transferredData: string[];
  createdAt: string;
}

// API Functions
export async function getPatients(): Promise<Patient[]> {
  const response = await fetch('/api/patients');
  if (!response.ok) throw new Error('Failed to fetch patients');
  const data = await response.json();
  // Convert temperature from stored format (celsius * 10) back to celsius
  return data.map((p: any) => ({ ...p, temperature: p.temperature / 10 }));
}

export async function createPatient(patient: Omit<Patient, 'id' | 'createdAt' | 'synced' | 'medicalHistory' | 'allergies' | 'currentMedications' | 'bloodType'>): Promise<Patient> {
  const response = await fetch('/api/patients', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...patient,
      temperature: Math.round(patient.temperature * 10), // Store as celsius * 10
      medicalHistory: [],
      allergies: [],
      currentMedications: [],
      bloodType: 'Unknown',
      synced: true
    }),
  });
  if (!response.ok) throw new Error('Failed to create patient');
  const data = await response.json();
  return { ...data, temperature: data.temperature / 10 };
}

export async function getDoctors(search?: string): Promise<Doctor[]> {
  const url = search ? `/api/doctors?search=${encodeURIComponent(search)}` : '/api/doctors';
  const response = await fetch(url);
  if (!response.ok) throw new Error('Failed to fetch doctors');
  const data = await response.json();
  // Convert rating from stored format (rating * 10) back to decimal
  return data.map((d: any) => ({ ...d, rating: d.rating / 10 }));
}

export async function getHospitals(search?: string): Promise<Hospital[]> {
  const url = search ? `/api/hospitals?search=${encodeURIComponent(search)}` : '/api/hospitals';
  const response = await fetch(url);
  if (!response.ok) throw new Error('Failed to fetch hospitals');
  const data = await response.json();
  // Convert rating from stored format (rating * 10) back to decimal
  return data.map((h: any) => ({ ...h, rating: h.rating / 10 }));
}

export async function getAppointments(): Promise<Appointment[]> {
  const response = await fetch('/api/appointments');
  if (!response.ok) throw new Error('Failed to fetch appointments');
  return response.json();
}

export async function createAppointment(appointment: Omit<Appointment, 'id' | 'createdAt'>): Promise<Appointment> {
  const response = await fetch('/api/appointments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(appointment),
  });
  if (!response.ok) throw new Error('Failed to create appointment');
  return response.json();
}

export async function getTransfers(): Promise<Transfer[]> {
  const response = await fetch('/api/transfers');
  if (!response.ok) throw new Error('Failed to fetch transfers');
  return response.json();
}

export async function createTransfer(transfer: Omit<Transfer, 'id' | 'createdAt' | 'status'>): Promise<Transfer> {
  const response = await fetch('/api/transfers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...transfer, status: 'pending' }),
  });
  if (!response.ok) throw new Error('Failed to create transfer');
  return response.json();
}

export async function updateTransferStatus(id: string, status: 'pending' | 'accepted' | 'completed'): Promise<Transfer> {
  const response = await fetch(`/api/transfers/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status }),
  });
  if (!response.ok) throw new Error('Failed to update transfer status');
  return response.json();
}

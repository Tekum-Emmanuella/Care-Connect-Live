import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createPatient } from "@/lib/api";
import { useStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { WifiOff, Save, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

const formSchema = z.object({
  name: z.string().min(2, "Patient name is required"),
  age: z.coerce.number().min(0, "Age must be positive").max(120),
  village: z.string().min(2, "Village name is required"),
  symptoms: z.string().min(5, "Please describe symptoms"),
  temperature: z.coerce.number().min(30).max(45),
  bloodPressure: z.string().regex(/^\d{2,3}\/\d{2,3}$/, "Format: 120/80"),
  heartRate: z.coerce.number().min(30).max(250),
  severity: z.enum(['low', 'medium', 'critical'])
});

export default function NurseIntake() {
  const { isOffline, addToSyncQueue } = useStore();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      age: undefined,
      village: "",
      symptoms: "",
      temperature: undefined,
      bloodPressure: "",
      heartRate: undefined,
      severity: "low"
    }
  });

  const createPatientMutation = useMutation({
    mutationFn: createPatient,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['patients'] });
      toast({
        title: "Patient Record Synced",
        description: "Data successfully uploaded to the central database.",
        className: "border-green-400 bg-green-50"
      });
      form.reset();
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    if (isOffline) {
      // Add to sync queue for offline processing
      addToSyncQueue({
        type: 'patient',
        data: values,
        timestamp: new Date().toISOString()
      });
      
      toast({
        title: "Saved to Offline Queue",
        description: "Record will sync automatically when connectivity is restored.",
        className: "border-orange-400 bg-orange-50"
      });
      
      form.reset();
    } else {
      createPatientMutation.mutate(values);
    }
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-heading font-bold text-primary">Patient Intake</h2>
          <p className="text-muted-foreground">Record new patient vitals and symptoms.</p>
        </div>
        {isOffline && (
          <div className="bg-orange-100 text-orange-800 px-4 py-2 rounded-full flex items-center gap-2 text-sm font-medium animate-pulse">
            <WifiOff className="w-4 h-4" />
            Offline Mode Active
          </div>
        )}
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="shadow-lg border-none bg-white/80 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-xl font-heading">Patient Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} data-testid="input-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Age</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="25" {...field} data-testid="input-age" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="village"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Village/Town</FormLabel>
                      <FormControl>
                        <Input placeholder="Bafut" {...field} data-testid="input-village" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="severity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Severity</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-severity">
                            <SelectValue placeholder="Select severity" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="symptoms"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Symptoms</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe patient symptoms..." 
                        className="min-h-24"
                        {...field}
                        data-testid="textarea-symptoms"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card className="shadow-lg border-none bg-white/80 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-xl font-heading">Vital Signs</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="temperature"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Temperature (°C)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1" 
                          placeholder="36.5" 
                          {...field}
                          data-testid="input-temperature"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="bloodPressure"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blood Pressure</FormLabel>
                      <FormControl>
                        <Input placeholder="120/80" {...field} data-testid="input-blood-pressure" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="heartRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Heart Rate (bpm)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="72" 
                          {...field}
                          data-testid="input-heart-rate"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <motion.div whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}>
            <Button 
              type="submit" 
              className="w-full h-14 text-lg rounded-2xl shadow-xl shadow-primary/20 bg-primary hover:bg-primary/90"
              disabled={createPatientMutation.isPending}
              data-testid="button-submit"
            >
              {createPatientMutation.isPending ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5 mr-2" />
                  {isOffline ? 'Save to Queue' : 'Submit Patient Record'}
                </>
              )}
            </Button>
          </motion.div>
        </form>
      </Form>
    </div>
  );
}

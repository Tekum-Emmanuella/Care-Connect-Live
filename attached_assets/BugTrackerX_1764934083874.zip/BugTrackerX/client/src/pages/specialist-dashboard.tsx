import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getPatients, getHospitals, getTransfers, createTransfer, updateTransferStatus } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Filter, 
  AlertCircle, 
  Activity, 
  Users, 
  Ambulance,
  ArrowRightLeft,
  CheckCircle2,
  Clock
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { MedicalRecordView } from "@/components/medical-record-view";

export default function SpecialistDashboard() {
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  const [transferHospital, setTransferHospital] = useState<string>("");
  const [transferReason, setTransferReason] = useState("");
  const [transferPriority, setTransferPriority] = useState<'routine' | 'urgent' | 'emergency'>("routine");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch data
  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => getPatients(),
  });

  const { data: hospitals = [] } = useQuery({
    queryKey: ['hospitals'],
    queryFn: () => getHospitals(),
  });

  const { data: transfers = [] } = useQuery({
    queryKey: ['transfers'],
    queryFn: () => getTransfers(),
  });

  // Mutations
  const createTransferMutation = useMutation({
    mutationFn: createTransfer,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transfers'] });
      setSelectedPatient(null);
      setTransferReason("");
      setTransferHospital("");
      toast({
        title: "Transfer Initiated 🚑",
        description: "Patient records encrypted and forwarded to destination facility.",
        className: "bg-blue-50 border-blue-200 text-blue-900"
      });
    },
  });

  const updateTransferMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: 'pending' | 'accepted' | 'completed' }) =>
      updateTransferStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transfers'] });
      toast({
        title: "Transfer Updated",
        description: "Transfer status has been updated successfully.",
      });
    },
  });

  const handleTransfer = () => {
    if (selectedPatient && transferHospital) {
      const patient = patients.find(p => p.id === selectedPatient);
      const fromHospital = hospitals[0]; // Assume current hospital
      
      if (patient && fromHospital) {
        createTransferMutation.mutate({
          patientId: patient.id,
          patientName: patient.name,
          fromHospitalId: fromHospital.id,
          toHospitalId: transferHospital,
          reason: transferReason,
          priority: transferPriority,
          transferredData: [
            `Vitals: ${patient.temperature}°C, ${patient.bloodPressure}, HR ${patient.heartRate}`,
            `Medical History: ${patient.medicalHistory.join(', ')}`,
            `Allergies: ${patient.allergies.join(', ')}`,
            `Current Medications: ${patient.currentMedications.join(', ')}`
          ],
        });
      }
    }
  };

  // Mock data for the chart
  const chartData = [
    { time: '08:00', avgTemp: 36.5, avgBP: 115 },
    { time: '10:00', avgTemp: 36.8, avgBP: 118 },
    { time: '12:00', avgTemp: 37.1, avgBP: 122 },
    { time: '14:00', avgTemp: 37.4, avgBP: 125 },
    { time: '16:00', avgTemp: 37.0, avgBP: 120 },
    { time: '18:00', avgTemp: 36.7, avgBP: 116 },
  ];

  const criticalCount = patients.filter(p => p.severity === 'critical').length;
  const mediumCount = patients.filter(p => p.severity === 'medium').length;
  const pendingTransfers = transfers.filter(t => t.status === 'pending');

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-heading font-bold text-foreground">Medical Dashboard</h2>
          <p className="text-muted-foreground">Overview of rural clinic intakes and critical cases.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" data-testid="button-filter">
            <Filter className="w-4 h-4 mr-2" /> Filter
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90" data-testid="button-generate-report">
            Generate Report
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-patients">{patients.length}</div>
            <p className="text-xs text-muted-foreground">+12% from last week</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-red-100 bg-red-50/30">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-red-900">Critical Cases</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600" data-testid="text-critical-cases">{criticalCount}</div>
            <p className="text-xs text-red-800/70">Requires immediate review</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-yellow-100 bg-yellow-50/30">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-yellow-900">Medium Risk</CardTitle>
            <Activity className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600" data-testid="text-medium-risk">{mediumCount}</div>
            <p className="text-xs text-yellow-800/70">Monitor vitals daily</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-blue-100 bg-blue-50/30">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-900">Pending Transfers</CardTitle>
            <Ambulance className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600" data-testid="text-pending-transfers">{pendingTransfers.length}</div>
            <p className="text-xs text-blue-800/70">Inter-hospital referrals</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Patient List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold font-heading">Recent Intakes</h3>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search patients..." className="pl-8" data-testid="input-search-patients" />
            </div>
          </div>

          <Card>
            <div className="p-0 overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-muted/50 text-muted-foreground font-medium border-b">
                  <tr>
                    <th className="px-4 py-3">Patient</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Vitals</th>
                    <th className="px-4 py-3">Village</th>
                    <th className="px-4 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {patients.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                        No patient records found.
                      </td>
                    </tr>
                  ) : (
                    patients.map((patient) => (
                      <tr key={patient.id} className="hover:bg-muted/20 transition-colors" data-testid={`row-patient-${patient.id}`}>
                        <td className="px-4 py-3">
                          <div className="font-medium text-foreground">{patient.name}</div>
                          <div className="text-xs text-muted-foreground">{patient.age} years</div>
                        </td>
                        <td className="px-4 py-3">
                          <Badge 
                            variant={patient.severity === 'critical' ? 'destructive' : patient.severity === 'medium' ? 'default' : 'secondary'}
                            className={patient.severity === 'medium' ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200' : ''}
                          >
                            {patient.severity}
                          </Badge>
                        </td>
                        <td className="px-4 py-3">
                          <div className="text-xs space-y-0.5">
                            <div>{patient.temperature}°C</div>
                            <div className="text-muted-foreground">{patient.bloodPressure}</div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{patient.village}</td>
                        <td className="px-4 py-3 text-right">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="sm" onClick={() => setSelectedPatient(patient.id)} data-testid={`button-transfer-${patient.id}`}>
                                <ArrowRightLeft className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>Initiate Patient Transfer</DialogTitle>
                                <DialogDescription>
                                  Transfer {patient.name} to another facility with complete medical records.
                                </DialogDescription>
                              </DialogHeader>
                              
                              {/* Medical Record Preview */}
                              <div className="my-4">
                                <h4 className="font-semibold mb-2 text-sm text-muted-foreground">Patient Medical Record</h4>
                                <div className="border rounded-lg p-4 bg-muted/20">
                                  <MedicalRecordView patient={patient} compact />
                                </div>
                              </div>

                              <div className="space-y-4">
                                <div className="space-y-2">
                                  <Label htmlFor="hospital">Destination Hospital</Label>
                                  <Select value={transferHospital} onValueChange={setTransferHospital}>
                                    <SelectTrigger id="hospital" data-testid="select-hospital">
                                      <SelectValue placeholder="Select hospital" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {hospitals.map(h => (
                                        <SelectItem key={h.id} value={h.id}>{h.name} - {h.location}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>

                                <div className="space-y-2">
                                  <Label htmlFor="priority">Priority</Label>
                                  <Select value={transferPriority} onValueChange={(v: any) => setTransferPriority(v)}>
                                    <SelectTrigger id="priority" data-testid="select-priority">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="routine">Routine</SelectItem>
                                      <SelectItem value="urgent">Urgent</SelectItem>
                                      <SelectItem value="emergency">Emergency</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>

                                <div className="space-y-2">
                                  <Label htmlFor="reason">Transfer Reason</Label>
                                  <Textarea 
                                    id="reason"
                                    placeholder="Reason for transfer..." 
                                    value={transferReason}
                                    onChange={(e) => setTransferReason(e.target.value)}
                                    data-testid="textarea-reason"
                                  />
                                </div>
                              </div>

                              <DialogFooter>
                                <Button 
                                  onClick={handleTransfer} 
                                  disabled={!transferHospital}
                                  className="w-full"
                                  data-testid="button-confirm-transfer"
                                >
                                  <Ambulance className="w-4 h-4 mr-2" />
                                  Initiate Transfer
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Right Sidebar - Transfers & Chart */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Ambulance className="w-4 h-4" />
                Pending Transfers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {pendingTransfers.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">No pending transfers</p>
              ) : (
                pendingTransfers.map((transfer) => (
                  <div key={transfer.id} className="p-3 border rounded-lg space-y-2" data-testid={`card-transfer-${transfer.id}`}>
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-medium text-sm">{transfer.patientName}</div>
                        <div className="text-xs text-muted-foreground">
                          {hospitals.find(h => h.id === transfer.toHospitalId)?.name || 'Unknown Hospital'}
                        </div>
                      </div>
                      <Badge 
                        variant={transfer.priority === 'emergency' ? 'destructive' : 'default'}
                        className={transfer.priority === 'urgent' ? 'bg-yellow-100 text-yellow-800' : ''}
                      >
                        {transfer.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{transfer.reason}</p>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 text-xs"
                        onClick={() => updateTransferMutation.mutate({ id: transfer.id, status: 'accepted' })}
                        data-testid={`button-accept-${transfer.id}`}
                      >
                        <CheckCircle2 className="w-3 h-3 mr-1" /> Accept
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 text-xs"
                        onClick={() => updateTransferMutation.mutate({ id: transfer.id, status: 'completed' })}
                        data-testid={`button-complete-${transfer.id}`}
                      >
                        <Clock className="w-3 h-3 mr-1" /> Complete
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Vitals Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="time" fontSize={10} />
                  <YAxis fontSize={10} />
                  <Tooltip />
                  <Line type="monotone" dataKey="avgTemp" stroke="#8B5CF6" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="avgBP" stroke="#FF6B6B" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

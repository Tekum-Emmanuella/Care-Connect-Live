import { useQuery } from "@tanstack/react-query";
import { getHospitals } from "@/lib/api";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, MapPin, Star, Siren, Bed, Phone
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

export default function HospitalsDirectory() {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: hospitals = [] } = useQuery({
    queryKey: ['hospitals'],
    queryFn: () => getHospitals(),
  });

  const filteredHospitals = hospitals.filter(h => 
    h.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-4xl font-heading font-black text-foreground tracking-tight">Hospital Network</h2>
          <p className="text-lg text-muted-foreground">Find accredited facilities and specialized care centers.</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-2xl">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
        <Input 
          placeholder="Search hospitals by name, city, or facility..." 
          className="pl-12 h-14 rounded-2xl text-lg shadow-sm border-transparent bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          data-testid="input-search-hospitals"
        />
      </div>

      {/* Hospital Grid */}
      <div className="grid md:grid-cols-2 gap-8">
        <AnimatePresence>
          {filteredHospitals.map((hospital) => (
            <motion.div
              key={hospital.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              layout
            >
              <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300 group bg-white rounded-3xl h-full flex flex-col" data-testid={`card-hospital-${hospital.id}`}>
                <div className="h-48 relative overflow-hidden">
                  <img 
                    src={hospital.image} 
                    alt={hospital.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-2xl font-bold font-heading leading-tight" data-testid={`text-hospital-name-${hospital.id}`}>{hospital.name}</h3>
                    <p className="text-white/80 flex items-center gap-1.5 text-sm mt-1">
                      <MapPin className="w-4 h-4" /> {hospital.location} • {hospital.type}
                    </p>
                  </div>

                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 text-amber-500 shadow-sm">
                    <Star className="w-3 h-3 fill-current" /> {hospital.rating}
                  </div>
                </div>

                <CardContent className="pt-6 flex-1 space-y-6">
                  {/* Key Stats */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className={`p-3 rounded-xl border ${hospital.ambulanceAvailable ? 'bg-green-50 border-green-100 text-green-700' : 'bg-red-50 border-red-100 text-red-700'}`}>
                      <div className="flex items-center gap-2 mb-1 font-bold text-sm">
                        <Siren className="w-4 h-4" /> Emergency
                      </div>
                      <div className="text-xs opacity-90">
                        {hospital.ambulanceAvailable ? 'Ambulance On-Site' : 'No Ambulance'}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-blue-50 border border-blue-100 text-blue-700">
                       <div className="flex items-center gap-2 mb-1 font-bold text-sm">
                        <Bed className="w-4 h-4" /> Capacity
                      </div>
                      <div className="text-xs opacity-90">
                        {hospital.icuBeds} ICU Beds Available
                      </div>
                    </div>
                  </div>

                  {/* Specs */}
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Facilities</h4>
                      <div className="flex flex-wrap gap-2">
                        {hospital.facilities.map(f => (
                          <Badge key={f} variant="secondary" className="bg-secondary/10 text-secondary hover:bg-secondary/20">
                            {f}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Specialties</h4>
                      <div className="flex flex-wrap gap-2">
                        {hospital.specialties.map(s => (
                          <Badge key={s} variant="outline" className="text-xs">
                            {s}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="border-t bg-muted/20 p-4">
                  <Button className="w-full rounded-xl h-12 font-semibold shadow-sm bg-white text-primary border border-primary/20 hover:bg-primary/5" data-testid={`button-contact-${hospital.id}`}>
                    <Phone className="w-4 h-4 mr-2" /> Contact Reception
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

import { useStore } from "@/lib/store";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { UserRound, Stethoscope, HeartPulse, ArrowRight } from "lucide-react";
import logoImage from "@assets/generated_images/minimalist_medical_connectivity_logo.png";
import heroImage from "@assets/generated_images/vibrant_happy_diverse_people_using_health_app.png";

export default function Home() {
  const { setRole } = useStore();
  const [, setLocation] = useLocation();

  const handleLogin = (role: 'nurse' | 'specialist' | 'patient') => {
    setRole(role);
    if (role === 'nurse') setLocation('/nurse');
    else if (role === 'specialist') setLocation('/specialist');
    else setLocation('/patient');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10 opacity-30">
         <div className="absolute top-[-10%] right-[-10%] w-[600px] h-[600px] bg-gradient-to-br from-primary/40 to-purple-500/40 rounded-full blur-3xl" />
         <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-gradient-to-tr from-secondary/40 to-orange-400/40 rounded-full blur-3xl" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="container max-w-6xl px-6 py-12 grid lg:grid-cols-2 gap-12 items-center"
      >
        {/* Left Content */}
        <div className="space-y-8">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm border border-white/50">
               <img src={logoImage} alt="Logo" className="w-6 h-6 rounded" />
               <span className="font-bold text-primary tracking-wide text-sm uppercase">HealthHub Cameroon</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-heading font-black text-foreground leading-[1.1] tracking-tight">
              Healthcare <br/>
              <span className="gradient-text">Without Limits</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-lg leading-relaxed">
              Connecting rural communities with world-class specialists. Book appointments, track vitals, and stay healthy—anywhere, anytime.
            </p>
          </div>

          <div className="grid gap-4 pt-4">
            <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider pl-1">Select Your Portal</p>
            
            <div className="grid sm:grid-cols-3 gap-4">
              {/* Patient Card */}
              <motion.button
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleLogin('patient')}
                className="glass-card p-6 rounded-2xl text-left group relative overflow-hidden border-t-4 border-t-secondary"
              >
                <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center text-secondary mb-4 group-hover:bg-secondary group-hover:text-white transition-colors">
                  <HeartPulse className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold font-heading">Patient</h3>
                <p className="text-sm text-muted-foreground mt-1">Find doctors & book visits</p>
              </motion.button>

              {/* Nurse Card */}
              <motion.button
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleLogin('nurse')}
                className="glass-card p-6 rounded-2xl text-left group relative overflow-hidden border-t-4 border-t-primary"
              >
                 <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4 group-hover:bg-primary group-hover:text-white transition-colors">
                  <UserRound className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold font-heading">Nurse</h3>
                <p className="text-sm text-muted-foreground mt-1">Rural clinic intake portal</p>
              </motion.button>

              {/* Specialist Card */}
              <motion.button
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleLogin('specialist')}
                className="glass-card p-6 rounded-2xl text-left group relative overflow-hidden border-t-4 border-t-purple-600"
              >
                 <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 mb-4 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <Stethoscope className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold font-heading">Doctor</h3>
                <p className="text-sm text-muted-foreground mt-1">Specialist dashboard</p>
              </motion.button>
            </div>
          </div>
        </div>

        {/* Right Image */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="hidden lg:block relative"
        >
          <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-secondary/20 rounded-[3rem] blur-2xl -z-10 transform rotate-6" />
          <img 
            src={heroImage} 
            alt="Happy diverse people using health app" 
            className="w-full h-auto rounded-[2.5rem] shadow-2xl border-8 border-white/40"
          />
          
          {/* Floating Badge */}
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
            className="absolute -bottom-8 -left-8 glass p-4 rounded-2xl flex items-center gap-4 max-w-xs"
          >
            <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold text-lg">
              24/7
            </div>
            <div>
              <p className="font-bold text-foreground">Always Available</p>
              <p className="text-xs text-muted-foreground">Instant access to 500+ specialists across Cameroon</p>
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}

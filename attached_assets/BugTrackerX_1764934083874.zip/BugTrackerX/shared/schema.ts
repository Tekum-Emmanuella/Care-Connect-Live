import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const patients = pgTable("patients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  village: text("village").notNull(),
  symptoms: text("symptoms").notNull(),
  temperature: integer("temperature").notNull(), // stored as celsius * 10 for precision
  bloodPressure: text("blood_pressure").notNull(),
  heartRate: integer("heart_rate").notNull(),
  severity: text("severity").notNull(), // 'low' | 'medium' | 'critical'
  medicalHistory: jsonb("medical_history").notNull().default(sql`'[]'::jsonb`),
  allergies: jsonb("allergies").notNull().default(sql`'[]'::jsonb`),
  currentMedications: jsonb("current_medications").notNull().default(sql`'[]'::jsonb`),
  bloodType: text("blood_type").notNull().default('Unknown'),
  synced: boolean("synced").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const doctors = pgTable("doctors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  hospital: text("hospital").notNull(),
  location: text("location").notNull(),
  image: text("image").notNull(),
  availableSlots: jsonb("available_slots").notNull().default(sql`'[]'::jsonb`),
  rating: integer("rating").notNull().default(45), // stored as rating * 10
});

export const hospitals = pgTable("hospitals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  location: text("location").notNull(),
  type: text("type").notNull(), // 'General' | 'Specialized' | 'Clinic'
  image: text("image").notNull(),
  facilities: jsonb("facilities").notNull().default(sql`'[]'::jsonb`),
  specialties: jsonb("specialties").notNull().default(sql`'[]'::jsonb`),
  rating: integer("rating").notNull().default(45),
  ambulanceAvailable: boolean("ambulance_available").notNull().default(false),
  icuBeds: integer("icu_beds").notNull().default(0),
});

export const appointments = pgTable("appointments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  doctorId: varchar("doctor_id").notNull(),
  doctorName: text("doctor_name").notNull(),
  hospital: text("hospital").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  status: text("status").notNull().default('confirmed'), // 'confirmed' | 'pending' | 'completed'
  videoLink: text("video_link"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const transfers = pgTable("transfers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: varchar("patient_id").notNull(),
  patientName: text("patient_name").notNull(),
  fromHospitalId: varchar("from_hospital_id").notNull(),
  toHospitalId: varchar("to_hospital_id").notNull(),
  reason: text("reason").notNull(),
  priority: text("priority").notNull(), // 'routine' | 'urgent' | 'emergency'
  status: text("status").notNull().default('pending'), // 'pending' | 'accepted' | 'completed'
  transferredData: jsonb("transferred_data").notNull().default(sql`'[]'::jsonb`),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
  createdAt: true,
});

export const insertDoctorSchema = createInsertSchema(doctors).omit({
  id: true,
});

export const insertHospitalSchema = createInsertSchema(hospitals).omit({
  id: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
});

export const insertTransferSchema = createInsertSchema(transfers).omit({
  id: true,
  createdAt: true,
});

// Types
export type Patient = typeof patients.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;

export type Doctor = typeof doctors.$inferSelect;
export type InsertDoctor = z.infer<typeof insertDoctorSchema>;

export type Hospital = typeof hospitals.$inferSelect;
export type InsertHospital = z.infer<typeof insertHospitalSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type Transfer = typeof transfers.$inferSelect;
export type InsertTransfer = z.infer<typeof insertTransferSchema>;
